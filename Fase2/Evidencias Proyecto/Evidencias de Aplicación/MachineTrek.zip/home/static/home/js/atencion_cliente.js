function toggleContactForm() {
    const form = document.getElementById("contactForm");
    form.style.display = form.style.display === "none" ? "block" : "none";
}