/*//Se utiliza solo en la carga inicial de la pagina para entregar el usuario como variable al js
var user = '{{request.user}}'
//se implementa el csrf token, puede ser que haya que adaptar el código.
function getToken(name) {
    var cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue
}
var csrftoken = getToken('csrftoken');*/